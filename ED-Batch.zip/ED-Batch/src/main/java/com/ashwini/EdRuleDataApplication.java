package com.ashwini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdRuleDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdRuleDataApplication.class, args);
	}

}
