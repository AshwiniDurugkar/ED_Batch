package com.ashwini.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name ="eligibility_details")
public class EligibilityDetails {
	
	@Id
	@GeneratedValue
	@Column(name = "ED_TRACE_ID")
	private Integer ed_trace_id;
	
	@Column(name = "BENEFIT_AMT")
	private Double benefit_amt;
	
	@Column(name = "CASE_NUM")
	private Integer case_no;
	
	@Column(name = "CREATE_DT")
	private Date create_dt;
	
	@Column(name = "DENIAL_REASON")
	private String denial_reason;
	
	@Column(name = "PLAN_END_DT")
	private String plan_end_dt;
	
	@Column(name = "PLAN_NAME")
	private String plan_name;
	
	@Column(name = "PLAN_START_DT")
	private String plan_start_dt;
	
	@Column(name = "PLAN_STATUS")
	private String plan_status;
	
	@Column(name = "UPDATE_DT")
	private Date update_dt;
	
	
	
	
	
	
	
	
	

}
