package com.ashwini.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ashwini.entity.CoPdfs;

@Repository
public interface CoPdfRepository  extends JpaRepository<CoPdfs, Serializable>{
	

}
