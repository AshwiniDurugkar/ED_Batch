package com.ashwini.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ashwini.entity.CoTriggers;
import com.ashwini.entity.EligibilityDetails;
@Repository
public interface EligibilityRepository  extends JpaRepository<EligibilityDetails,Serializable>{

}
