package com.ashwini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdRuleDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
